import { V, _ } from "../chunks/2.Z6KyGJbu.js";
export {
  V as component,
  _ as universal
};
